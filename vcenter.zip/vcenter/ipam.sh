#!/bin/bash

echo "DnsServerList=8.8.8.8,8.8.4.4"
echo "nicCount=1"  # This is a mandatory parameter and is always set to 1
echo "nicIP_0=10.72.86.173"
echo "nicDnsServerList_0=8.8.8.8,8.8.4.4"
echo "nicGateway_0=10.72.86.1"
echo "nicNetmask_0=255.255.255.0"
echo "domainName=localhost"
echo "hwClockUTC=true"
echo "timeZone=Canada/Eastern"
echo "osHostname=testhost1"
